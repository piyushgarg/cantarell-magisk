<h1 align="center">Cantarell Font Magisk Module </h1>

<div align="center">
  <strong>Cantarell Font.
</div>
